import java.awt.Color;

import fr.irit.smac.amak.Agent;
import fr.irit.smac.lxplot.LxPlot;
import fr.irit.smac.lxplot.commons.ChartType;

public class Philosopher extends Agent<SmaPhilosopher, Table>{
	
	int id;
	Fork myFork, neighbourFork;
	double hunger;

	public Philosopher(int id, SmaPhilosopher amas, Fork myFork, Fork neighbourFork) {
		super(amas, id, myFork, neighbourFork);
	}
	
	@Override
	protected void onReady() {
		hunger = amas.getEnvironment().getRandom().nextInt(amas.getEnvironment().getForks().length);
	}
	
	protected double computeCriticality() {
	   	return hunger;
	}
	protected void onPerceiveDecideAct() {
		if (hunger > 20) {
			if (neighbourFork.tryTake(this) && myFork.tryTake(this)) {
				hunger = 0;
				neighbourFork.release(this);
				myFork.tryTake(this);
			}
		}
	}
	
	 protected void onUpdateRender() {
	        LxPlot.getChart("Eaten Pastas", ChartType.BAR, false).add(id, 2);
	}
	 
	 public void cycle() {
			hunger++;
	 }
}
