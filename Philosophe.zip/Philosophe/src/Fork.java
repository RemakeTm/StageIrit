import fr.irit.smac.amak.examples.philosophers.PhilosopherExample;

public class Fork {
	
	private Philosopher takenBy;
	
	public synchronized boolean tryTake(Philosopher asker) {
		if (takenBy != null) {
			return false;
		}
		takenBy = asker;
		return true;
	}
	
	public synchronized void release (Philosopher asker) {
		if(takenBy == asker) {
			takenBy = null;
		}
	}

}
