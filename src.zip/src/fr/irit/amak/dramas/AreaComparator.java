package fr.irit.amak.dramas;

import java.util.Comparator;

public class AreaComparator implements Comparator<Area>{

	@Override
	public int compare(Area o1, Area o2) {
		Double crit1 = o1.computeCriticality();
		Double crit2 = o2.computeCriticality();
		int resCrit = crit2.compareTo(crit1);
		
		
		if (resCrit == 0) {
			Double time1 = o1.getTimeSinceLastSeen();
			Double time2 = o2.getTimeSinceLastSeen();
			int resTime = time2.compareTo(time1);
			
			if (resTime == 0) {
				Integer x1 = o1.getX();
				Integer x2 = o2.getX();
				int resX = x1.compareTo(x2);
				
				if (resX == 0) {
					Integer y1 = o1.getY();
					Integer y2 = o2.getY();
					return y1.compareTo(y2);
				}
				return resX;		
			}
			return resTime;		
		}		
		return resCrit;
	}

}
